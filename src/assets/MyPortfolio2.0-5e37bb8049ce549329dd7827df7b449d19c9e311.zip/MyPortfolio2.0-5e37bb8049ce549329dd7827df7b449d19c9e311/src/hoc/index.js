import SectionWrapper from '/src/hoc/SectionWrapper.jsx';

export { SectionWrapper };